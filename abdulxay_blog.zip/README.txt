Abdulxay.com - Simple static blog
================================

Fayllar:
- index.html  -> Bosh sahifa (profil va maqolalar namunasi)
- styles.css  -> Saytning uslubi (CSS)
- README.txt  -> Bu hujjat

Qanday ishlatish (VS Code yoki oddiy fayl tizimi):
1. Ushbu fayllarni bitta papkaga joylang.
2. index.html faylni brauzerda oching (ikkimarta bosish yoki 'Open with Live Server' VS Code extension orqali).
3. O'zgartirishlar kiritish uchun index.html va styles.css fayllarni tahrir qiling.

Profil rasmini o'zgartirish:
- index.html fayl ichidagi <img class="profile-img" src="..."> manzilini o'zingizga mos URL bilan almashtiring,
  yoki rasmni papkaga yuklab `src="img/myphoto.jpg"` kabi yo'lni ko'rsating.

Chat va boshqa funksiyalar:
- Hozircha oddiy frontend shablon. Chat (JavaScript AI) qo'shish uchun men sizga keyingi bosqichda kod yozib bera olaman.

Enjoy! - Sizning yordamchingiz
